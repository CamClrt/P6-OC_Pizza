OC Pizza: Design a technical solution
=================

This is a student project made for the project 6 from [OpenClassrooms](https://openclassrooms.com/ )'s Python course.

The aim of this project is to design a technical for a customer (OC pizza).

## Made with

* Python 3.8
* MySQL 8, RDBMS
* Love 💙

## Versions

Created in:   July 2020  
Developed:    May/July 2020  
Last version: https://github.com/CamClrt

## Authors

**Camille Clarret** aka **Camoulty** or **CamClrt** : https://github.com/CamClrt/  
Baby dev 🐣 I'm learning 🐍 #Python with [OpenClassrooms](https://openclassrooms.com/ )
