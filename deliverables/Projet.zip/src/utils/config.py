"""This module store all the configurations data."""

# DATABASE CONFIG

# database
DATABASE_NAME = "OC_Pizza"
HOST_NAME = "localhost"
USER_NAME = "OC_Pizza_User"
USER_PASSWORD = "my-secret-pw"
DB_SQL_FILE = "src/models/database.sql"
